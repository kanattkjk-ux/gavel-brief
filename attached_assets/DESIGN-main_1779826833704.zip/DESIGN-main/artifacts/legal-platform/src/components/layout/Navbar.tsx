import { useState, useEffect } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { Scale } from "lucide-react";

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const { scrollY } = useScroll();

  useEffect(() => {
    return scrollY.onChange((latest) => {
      setScrolled(latest > 50);
    });
  }, [scrollY]);

  const scrollTo = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <motion.nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ease-in-out px-6 md:px-12 py-4 flex items-center justify-between ${
        scrolled ? "bg-white/70 backdrop-blur-md border-b border-border/50 shadow-sm" : "bg-transparent"
      }`}
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.8, ease: "easeOut" }}
    >
      <div className="flex items-center gap-2 cursor-pointer" onClick={() => scrollTo('hero')}>
        <Scale className="w-8 h-8 text-primary" />
        <span className="font-serif text-2xl font-bold tracking-tight text-foreground">
          Gavel &amp; Brief
        </span>
      </div>

      <div className="hidden md:flex items-center gap-8">
        {["Platform", "Features", "Analytics", "Testimonials"].map((item) => (
          <button
            key={item}
            onClick={() => scrollTo(item.toLowerCase())}
            className="text-sm font-medium text-foreground/80 hover:text-primary transition-colors duration-300"
          >
            {item}
          </button>
        ))}
      </div>

      <button className="bg-primary text-primary-foreground px-6 py-2.5 rounded-sm font-medium text-sm transition-all duration-300 hover:bg-primary/90 hover:shadow-lg hover:shadow-primary/20 relative overflow-hidden group">
        <span className="relative z-10">Get Started</span>
        <div className="absolute inset-0 h-full w-full bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full group-hover:animate-[shimmer_1.5s_infinite]"></div>
      </button>
    </motion.nav>
  );
}
