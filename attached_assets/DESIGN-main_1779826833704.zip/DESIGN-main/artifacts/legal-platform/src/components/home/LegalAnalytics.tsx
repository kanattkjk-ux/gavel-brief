import { useRef, useEffect, useState } from "react";
import { motion, useInView } from "framer-motion";

/* ─── Counter ──────────────────────────────────────────────── */
function Counter({ to, suffix = "" }: { to: number; suffix?: string }) {
  const [val, setVal] = useState(0);
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true });
  useEffect(() => {
    if (!inView) return;
    let start: number;
    const dur = 2000;
    const step = (ts: number) => {
      if (!start) start = ts;
      const p = Math.min((ts - start) / dur, 1);
      setVal(Math.floor(p * p * to));
      if (p < 1) requestAnimationFrame(step); else setVal(to);
    };
    requestAnimationFrame(step);
  }, [inView, to]);
  return <span ref={ref}>{val.toLocaleString()}{suffix}</span>;
}

/* ─── Area Chart (Image 1 style) ───────────────────────────── */
type Tab = "civil" | "criminal" | "corporate";

// Higher values so the line sits HIGH in the chart; varied for visible ups-and-downs
const CHART_DATA: Record<Tab, number[]> = {
  civil:     [0.38, 0.50, 0.62, 0.55, 0.70, 0.65, 0.78, 0.72, 0.82, 0.75, 0.88, 0.92],
  criminal:  [0.45, 0.55, 0.48, 0.68, 0.60, 0.75, 0.65, 0.80, 0.70, 0.78, 0.72, 0.85],
  corporate: [0.32, 0.48, 0.58, 0.52, 0.68, 0.72, 0.65, 0.80, 0.75, 0.82, 0.78, 0.90],
};
const QUARTERS = ["Q1'21","Q2","Q3","Q4","Q1'22","Q2","Q3","Q4","Q1'23","Q2","Q3","Q4"];

function AreaChart({ isInView }: { isInView: boolean }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [tab, setTab] = useState<Tab>("civil");
  const tabRef = useRef<Tab>("civil");
  const progressRef = useRef(0);
  const tRef = useRef(0);
  const inViewRef = useRef(false);
  inViewRef.current = isInView;

  useEffect(() => { tabRef.current = tab; progressRef.current = 0; }, [tab]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const dpr = window.devicePixelRatio || 1;

    const resize = () => {
      const w = canvas.clientWidth;
      const h = canvas.clientHeight;
      canvas.width = w * dpr;
      canvas.height = h * dpr;
    };
    resize();
    window.addEventListener("resize", resize);

    let raf: number;

    const draw = () => {
      // Fast smooth draw-in: ~0.025 per frame → fully drawn in ~40 frames (~0.66s at 60fps)
      if (inViewRef.current && progressRef.current < 1) {
        progressRef.current = Math.min(progressRef.current + 0.025, 1);
      }
      if (inViewRef.current) tRef.current += 0.025;

      const W = canvas.width / dpr;
      const H = canvas.height / dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, W, H);

      const data = CHART_DATA[tabRef.current];
      const n = data.length;
      const t = tRef.current;
      const padL = 14, padR = 14, padT = 12, padB = 22;
      const chartW = W - padL - padR;
      const chartH = H - padT - padB;
      const maxX = padL + chartW * progressRef.current;

      const getY = (i: number) => {
        // prominent up-down wave: ±0.07
        const wave = Math.sin(t * 1.5 + i * 0.7) * 0.07 + Math.sin(t * 0.9 + i * 1.1) * 0.04;
        const v = Math.max(0.05, Math.min(0.99, data[i] + wave));
        return padT + chartH - v * chartH * 0.9; // 90% of chart height used so dots are clearly visible
      };
      const getX = (i: number) => padL + (i / (n - 1)) * chartW;

      // Clip drawing to progress region
      ctx.save();
      ctx.beginPath();
      ctx.rect(0, 0, maxX + 2, H);
      ctx.clip();

      // Build smooth bezier path
      const drawCurve = () => {
        ctx.beginPath();
        ctx.moveTo(getX(0), getY(0));
        for (let i = 1; i < n; i++) {
          const px = getX(i - 1), py = getY(i - 1);
          const cx1 = px + (getX(i) - px) / 2.8;
          const cx2 = getX(i) - (getX(i) - px) / 2.8;
          ctx.bezierCurveTo(cx1, py, cx2, getY(i), getX(i), getY(i));
        }
      };

      // Area fill
      drawCurve();
      ctx.lineTo(maxX, padT + chartH);
      ctx.lineTo(padL, padT + chartH);
      ctx.closePath();
      const areaGrad = ctx.createLinearGradient(0, padT, 0, padT + chartH);
      areaGrad.addColorStop(0,   "rgba(201,168,76,0.38)");
      areaGrad.addColorStop(0.55,"rgba(201,168,76,0.10)");
      areaGrad.addColorStop(1,   "rgba(201,168,76,0.01)");
      ctx.fillStyle = areaGrad;
      ctx.fill();

      // Line
      drawCurve();
      ctx.strokeStyle = "#C9A84C";
      ctx.lineWidth = 2.2;
      ctx.lineJoin = "round";
      ctx.shadowColor = "#C9A84C";
      ctx.shadowBlur = 10;
      ctx.stroke();
      ctx.shadowBlur = 0;

      // Dots
      for (let i = 0; i < n; i++) {
        if (getX(i) > maxX + 1) break;
        ctx.beginPath();
        ctx.arc(getX(i), getY(i), 3.5, 0, Math.PI * 2);
        ctx.fillStyle = "#C9A84C";
        ctx.shadowColor = "#C9A84C";
        ctx.shadowBlur = 12;
        ctx.fill();
        ctx.shadowBlur = 0;
      }

      ctx.restore();

      // Quarter labels
      ctx.font = `${10 * dpr / dpr}px Inter,sans-serif`;
      ctx.fillStyle = "rgba(255,255,255,0.38)";
      ctx.textAlign = "center";
      for (let i = 0; i < n; i += 3) {
        ctx.fillText(QUARTERS[i], getX(i), H - 4);
      }

      raf = requestAnimationFrame(draw);
    };
    draw();

    return () => { window.removeEventListener("resize", resize); cancelAnimationFrame(raf); };
  }, []);

  const tabs: { key: Tab; label: string }[] = [
    { key: "civil", label: "Civil" },
    { key: "criminal", label: "Criminal" },
    { key: "corporate", label: "Corporate" },
  ];

  return (
    <div className="rounded-xl overflow-hidden h-full" style={{ background: "#100805", border: "1px solid rgba(201,168,76,0.15)" }}>
      <div className="flex items-start justify-between px-5 pt-5 pb-3">
        <div>
          <p className="text-white font-semibold text-sm tracking-wide leading-tight">Caseload momentum</p>
          <p className="text-white/35 text-[10px] uppercase tracking-[0.15em] mt-1">Last 12 quarters</p>
        </div>
        <div className="flex gap-1.5 flex-wrap justify-end">
          {tabs.map(({ key, label }) => (
            <button key={key} onClick={() => setTab(key)}
              className="text-[10px] uppercase tracking-[0.12em] font-semibold px-3 py-1 rounded-full transition-all duration-300"
              style={{
                border: tab === key ? "1px solid #C9A84C" : "1px solid rgba(255,255,255,0.14)",
                color: tab === key ? "#C9A84C" : "rgba(255,255,255,0.38)",
                background: tab === key ? "rgba(201,168,76,0.08)" : "transparent",
              }}>
              {label}
            </button>
          ))}
        </div>
      </div>
      <canvas ref={canvasRef} className="w-full" style={{ height: "170px", display: "block" }} />
    </div>
  );
}

/* ─── Live Case Console (Image 2 style) ─────────────────────── */
const CONSOLE_ROWS = [
  { label: "AI Analysis",      desc: "Relevant laws, risk, and next actions", pct: 92 },
  { label: "Lawyer Match",     desc: "Specialisation and location fit",       pct: 78 },
  { label: "Shared Workspace", desc: "Notes, files, chat, and timeline",      pct: 86 },
];

function LiveCaseConsole({ isInView }: { isInView: boolean }) {
  return (
    <div className="rounded-xl overflow-hidden h-full flex flex-col"
      style={{ background: "linear-gradient(145deg,#1a0a04 0%,#1f0c06 100%)", border: "1px solid rgba(201,168,76,0.13)" }}>
      <div className="flex items-center justify-between px-5 py-4 border-b" style={{ borderColor: "rgba(255,255,255,0.07)" }}>
        <p className="text-white text-[11px] font-bold uppercase tracking-[0.22em]">Live Case Console</p>
        <span className="flex items-center gap-1.5 text-[11px] text-emerald-400 font-semibold">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />AI Active
        </span>
      </div>

      <div className="px-5 py-4 space-y-5 flex-1">
        {CONSOLE_ROWS.map((row, i) => (
          <div key={i}>
            <div className="flex items-start justify-between mb-2">
              <div>
                <p className="text-white text-sm font-semibold">{row.label}</p>
                <p className="text-white/35 text-[11px] mt-0.5">{row.desc}</p>
              </div>
              <motion.span className="text-accent font-bold text-sm ml-4 flex-shrink-0"
                initial={{ opacity: 0 }} animate={isInView ? { opacity: 1 } : {}} transition={{ delay: 0.8 + i * 0.3 }}>
                {row.pct}%
              </motion.span>
            </div>

            {/* Track */}
            <div className="relative h-2.5 rounded-full overflow-hidden" style={{ background: "rgba(255,255,255,0.07)" }}>
              <motion.div
                className="absolute inset-y-0 left-0 rounded-full"
                style={{
                  background: "linear-gradient(to right, #7C1D2B 0%, #b86030 45%, #C9A84C 100%)",
                  boxShadow: "0 0 12px rgba(201,168,76,0.45)",
                }}
                initial={{ width: "0%" }}
                // Overshoot then land: simulates "loading scan" and settling
                animate={isInView ? { width: [`0%`, `${row.pct + 9}%`, `${row.pct + 3}%`, `${row.pct}%`] } : {}}
                transition={{
                  duration: 2.0,
                  times: [0, 0.72, 0.88, 1],
                  ease: "easeOut",
                  delay: 0.5 + i * 0.28,
                }}
              />
              {/* End cap glow */}
              <motion.div
                className="absolute inset-y-0 w-3 rounded-full"
                style={{ background: "rgba(255,220,100,0.55)", filter: "blur(3px)" }}
                initial={{ left: "0%" }}
                animate={isInView ? { left: [`0%`, `${row.pct - 2}%`] } : {}}
                transition={{ duration: 2.0, delay: 0.5 + i * 0.28, ease: "easeOut" }}
              />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ─── Section ────────────────────────────────────────────────── */
export default function LegalAnalytics() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const isInView = useInView(sectionRef, { once: true, margin: "-80px" });

  const stats = [
    { label: "Cases Handled", value: 50000, suffix: "+" },
    { label: "Success Rate",  value: 98,    suffix: "%" },
    { label: "Expert Lawyers", value: 500,  suffix: "+" },
  ];

  return (
    <section className="py-32 px-6 md:px-12 bg-background relative" ref={sectionRef}>
      <div className="max-w-7xl mx-auto">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={isInView ? { opacity: 1, y: 0 } : {}} transition={{ duration: 0.8 }} className="text-center mb-16">
          <p className="text-xs uppercase tracking-[0.25em] text-accent font-semibold mb-4">05 — Legal Analytics</p>
          <h2 className="font-serif text-4xl md:text-5xl font-bold text-foreground mb-4">Precision Legal Intelligence</h2>
          <p className="text-lg text-foreground/60 max-w-2xl mx-auto font-light">
            Data doesn't lie. Gavel & Brief provides predictive analytics on case outcomes, judge behaviours, and settlement probabilities.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          {stats.map((s, i) => (
            <motion.div key={i} initial={{ opacity: 0, y: 40 }} animate={isInView ? { opacity: 1, y: 0 } : {}} transition={{ duration: 0.8, delay: i * 0.15 }}
              className="bg-white border border-border/40 p-8 rounded-xl shadow-sm flex flex-col items-center text-center">
              <div className="font-serif text-5xl font-bold text-primary mb-2"><Counter to={s.value} suffix={s.suffix} /></div>
              <div className="text-xs uppercase tracking-widest text-foreground/55 font-semibold">{s.label}</div>
            </motion.div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8" style={{ minHeight: "270px" }}>
          <motion.div initial={{ opacity: 0, y: 30 }} animate={isInView ? { opacity: 1, y: 0 } : {}} transition={{ duration: 1, delay: 0.5 }} className="h-full">
            <AreaChart isInView={isInView} />
          </motion.div>
          <motion.div initial={{ opacity: 0, y: 30 }} animate={isInView ? { opacity: 1, y: 0 } : {}} transition={{ duration: 1, delay: 0.7 }} className="h-full">
            <LiveCaseConsole isInView={isInView} />
          </motion.div>
        </div>
      </div>
    </section>
  );
}
