import { useRef } from "react";
import Navbar from "@/components/layout/Navbar";
import HeroSection from "@/components/home/HeroSection";
import AILegalAssistant from "@/components/home/AILegalAssistant";
import SmartCaseMatching from "@/components/home/SmartCaseMatching";
import AffidavitBuilder from "@/components/home/AffidavitBuilder";
import VakilVoiceAI from "@/components/home/VakilVoiceAI";
import LegalAnalytics from "@/components/home/LegalAnalytics";
import Testimonials from "@/components/home/Testimonials";
import FinalCTA from "@/components/home/FinalCTA";

export default function Home() {
  return (
    <main className="relative min-h-screen bg-background text-foreground overflow-hidden">
      <Navbar />
      <HeroSection />
      <AILegalAssistant />
      <SmartCaseMatching />
      <AffidavitBuilder />
      <VakilVoiceAI />
      <LegalAnalytics />
      <Testimonials />
      <FinalCTA />
    </main>
  );
}
